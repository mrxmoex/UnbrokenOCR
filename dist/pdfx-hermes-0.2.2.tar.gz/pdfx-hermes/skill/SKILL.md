---
name: pdfx
description: "Extract PDFs, scans, and old German Fraktur print."
version: 0.2.2
author: m (MrxHermesx), Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [pdf, ocr, tesseract, fraktur, marker, kraken, kurrent, local]
    related_skills: [ocr-and-documents, pdf]
---

# pdfx — local PDF extract + OCR

One CLI for born-digital PDFs, scans, Fraktur print, optional Marker layout, and optional Kraken Kurrent HTR. **No cloud.** Does not ship model weights.

## When to Use

- Local PDF or image needs text
- Folder of scans / copies / old print
- Old German Fraktur (print) or Kurrent/Sütterlin (hand)
- Complex layout PDF (marker, if installed)

Don't use for: cloud OCR accounts; dumping third-party books from chat attachments without a local save path.

## Prerequisites

```bash
# CLI on PATH (after package INSTALL.sh)
command -v pdfx
# or: python3 "$PDFX_HOME/pdfx.py"

# System
tesseract -v
ocrmypdf --version
pdftoppm -v
python3 -c "import fitz"   # pymupdf for digital/inspect

# Fraktur: TESSDATA_PREFIX = directory with *.traineddata (incl. frk + deu)
export TESSDATA_PREFIX="${TESSDATA_PREFIX:-$HOME/.local/share/tessdata}"
test -f "$TESSDATA_PREFIX/frk.traineddata"
```

Optional: Marker venv under `$PDFX_HOME/.venv`; Kraken under `$PDFX_HOME/.venv-kraken` + models in `$PDFX_HOME/models/kraken/` (not in package).

Install package: see tarball `INSTALL.sh` / `README.md`.

## How to Run

Prefer `terminal` with generous `timeout` for OCR (minutes for multi-page Fraktur).

```bash
pdfx FILE --inspect
pdfx FILE --mode fraktur --pages 8-20 --out out.txt
```

## Quick Reference

| Kind | Command |
|------|---------|
| Inspect | `pdfx FILE --inspect` |
| Digital | `pdfx FILE --mode digital --pages 1-5` |
| Auto | `pdfx FILE` |
| Marker | `pdfx FILE --mode marker --pages 1-3` |
| Scan | `pdfx FILE --ocr --mode scan --pages 1-10` |
| Fraktur | `pdfx FILE --mode fraktur --pages 8-20` |
| Fraktur QA | `pdfx FILE --mode fraktur --engine images --dpi 300` |
| Kurrent | `pdfx FILE --mode kurrent --pages 1-2` |
| Crawl | `pdfx DIR --crawl` |
| Batch | `pdfx-batch-fraktur PDF OUT 20 ocrmypdf [start] [end]` |
| Metrics | `pdfx-metrics EXTRACT.txt --json` |

## Procedure

1. **Inspect** — `pdfx FILE --inspect`. Completion: JSON has `text_quality` + `recommend`.
2. **Route** — If `label: garbled` or recommend `ocr-fraktur-or-scan` → `--mode fraktur`. Else digital / scan / marker as table.
3. **Slice** — Always pass `--pages A-B` on large books before full-volume batch.
4. **OCR** — Fraktur default engine is **ocrmypdf** (Gate B). Use `--engine images` for QA.
5. **Batch** — `pdfx-batch-fraktur` in 20-page chunks; read `*.meta.json` craft warnings.
6. **Verify** — Spot-read 20 lines; optional `pdfx-metrics` craft stems.

## Google Fraktur trap

`kind: digital` + high chars ≠ usable text. Garbled Google Fraktur layers must not be indexed as the library extract. Details: `references/CONTROL_GATES.md`.

## Fraktur glyph templates

Optional clean alphabet/specimen charts for human/agent glyph QA (long‑s, capitals, ß, umlauts). Catalog: `references/fraktur-templates/INDEX.md`.  
Drop local JPGs under `$PDFX_HOME/references/fraktur-templates/` if desired — **not required** for OCR. Prefer labeled A–Z chart + historic Mainzer sheet for 19th‑c. books. Use `vision_analyze` on a template next to a bad crop when tokens are confusable.

## Pitfalls

- `TESSDATA_PREFIX` must be the **tessdata directory** (contains `frk.traineddata`), not its parent — wrong parent crashes tesseract recursively.
- `--pages` is required discipline on big PDFs; full-file OCR is slow.
- Kurrent on print Fraktur is the wrong tool; Fraktur print uses `frk`.
- Marker may need a local venv; GPU/Docker paths are optional and often missing.
- Package has **no** kraken weights and **no** tessdata files — install those on the host.

## Verification

- [ ] `pdfx FILE --inspect` prints `text_quality` + `recommend`
- [ ] Fraktur sample pages produce followable DE (`--mode fraktur --pages …`)
- [ ] `tesseract --list-langs` (with `TESSDATA_PREFIX`) includes `frk`
- [ ] Batch dry path: one 2-page chunk exits 0 and writes `.meta.json`
