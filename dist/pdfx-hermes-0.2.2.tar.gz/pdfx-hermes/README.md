# pdfx-hermes 0.2.2

Local PDF extract + OCR for Hermes Agent. **No cloud.** One CLI: `pdfx`.

Routes: born-digital (pymupdf) · scan OCR (ocrmypdf/tesseract) · Fraktur print (`deu+frk`) · optional Marker layout · optional Kraken Kurrent HTR.

This package does **not** ship model weights (tessdata, kraken `.mlmodel`, marker models).

## Quick install

```bash
# from extracted tarball
cd pdfx-hermes
chmod +x INSTALL.sh pdfx.py pdfx-batch-fraktur.sh pdfx_metrics.py
./INSTALL.sh --dry-run          # see what would happen
./INSTALL.sh                    # symlink ~/.local/bin/pdfx
./INSTALL.sh --skill            # also copy skill → ~/.hermes/skills/productivity/pdfx

# ensure PATH
export PATH="$HOME/.local/bin:$PATH"

# Fraktur language data (required for --mode fraktur)
mkdir -p ~/.local/share/tessdata
# Place frk.traineddata (+ deu.traineddata) in that directory.
# Fedora often: dnf install tesseract-langpack-deu
# frk may need manual download from tesseract tessdata_best/fast.
export TESSDATA_PREFIX="$HOME/.local/share/tessdata"
```

System packages (examples):

```bash
# Fedora
sudo dnf install tesseract tesseract-langpack-deu ocrmypdf poppler-utils python3

# Debian/Ubuntu
sudo apt install tesseract-ocr tesseract-ocr-deu tesseract-ocr-frk ocrmypdf poppler-utils python3

# digital inspect / extract
pip install --user pymupdf
# optional complex layout
# python3 -m venv $PDFX_HOME/.venv && $PDFX_HOME/.venv/bin/pip install marker-pdf pymupdf
# optional Kurrent HTR (weights NOT included)
# python3 -m venv $PDFX_HOME/.venv-kraken && … install kraken; put *.mlmodel under $PDFX_HOME/models/kraken/
```

## Copy-paste commands

```bash
# Inspect (quality gate — always start here)
pdfx FILE.pdf --inspect

# Born-digital text layer
pdfx FILE.pdf --mode digital --pages 1-5

# Auto (quality-aware; refuses garbled Google layers)
pdfx FILE.pdf

# Scan / photocopy
pdfx FILE.pdf --ocr --mode scan --pages 1-10

# Fraktur / blackletter PRINT (default engine: ocrmypdf)
pdfx FILE.pdf --mode fraktur --pages 8-20 --out out.txt

# Fraktur QA path (pdftoppm + tesseract @ 300 DPI)
pdfx FILE.pdf --mode fraktur --engine images --dpi 300 --pages 13-16 --out qa.txt

# Chunked Fraktur batch
pdfx-batch-fraktur FILE.pdf ./extract/fraktur 20 ocrmypdf 1 100

# Craft-term metrics on an extract
pdfx-metrics ./extract/fraktur/chunk_001-020.txt --json

# Complex layout (needs marker in PATH or $PDFX_HOME/.venv)
pdfx FILE.pdf --mode marker --pages 1-3

# Kurrent / Sütterlin hand (needs kraken + local mlmodel)
pdfx PAGE.png --mode kurrent

# Folder crawl
pdfx DIR --crawl
```

## Route table

| Kind | Command |
|------|---------|
| Inspect | `pdfx FILE --inspect` → read `text_quality` + `recommend` |
| Born-digital | `pdfx FILE --mode digital --pages 1-5` |
| Auto | `pdfx FILE` or `--mode auto` |
| Complex layout | `pdfx FILE --mode marker --pages 1-3` |
| Scan | `pdfx FILE --ocr --mode scan` |
| Fraktur print | `pdfx FILE --mode fraktur --pages 8-20` |
| Fraktur QA | add `--engine images --dpi 300` |
| Kurrent hand | `pdfx FILE --mode kurrent --pages 1-2` |
| Folder | `pdfx DIR --crawl` |
| Papers index | add `--index-paper` |

### Google Fraktur trap

If `--inspect` says `kind: digital` but `text_quality.label: garbled` → **do not** trust the embedded layer. Use `--mode fraktur`. Google Books Fraktur dumps look dense and “digital” but are unreadable / unsearchable garbage.

Lesson from Dachdecker control gates (see `skill/references/CONTROL_GATES.md`):

| Gate | Result |
|------|--------|
| A rear smoke | PASS — fraktur recovers craft DE |
| B engine bakeoff | **ocrmypdf default** (~2.6× faster than images; craft tied) |
| C 20-page chunk | PASS — density holds; batch-ready |

Locked defaults in **0.2.2**: Fraktur `--engine auto` → **ocrmypdf**; QA → `--engine images`; chunk size 20.

## Environment

| Var | Meaning |
|-----|---------|
| `PDFX_HOME` / `PDFX_ROOT` | Install root (venv + models live here) |
| `TESSDATA_PREFIX` | Directory containing `*.traineddata` (**not** the parent of `tessdata/`) |
| `PDFX_KRAKEN_MODELS` | Override HTR model directory |
| `PDFX_DPI` | Batch render DPI (default 300) |

## Layout

```
pdfx-hermes/
  VERSION                 # 0.2.2
  MANIFEST.txt
  README.md
  INSTALL.sh
  pdfx.py                 # CLI
  pdfx-batch-fraktur.sh
  pdfx_metrics.py
  skill/
    SKILL.md              # Hermes portable skill
    references/CONTROL_GATES.md
    scripts/              # batch + metrics copies
```

## Hermes skill

```bash
./INSTALL.sh --skill
# or manually:
cp -a skill ~/.hermes/skills/productivity/pdfx
# optional-skills path in hermes-agent repo:
# optional-skills/productivity/pdfx/
```

Skill name: `pdfx`. Load with Hermes `skill_view(name='pdfx')` after install (new session if loader cached).

## Honesty

- Kurrent models on **modern print** look like garbage — expected.
- Fraktur **print** → tesseract `frk`, not kraken.
- Real Kurrent pages → `--mode kurrent`.
- Marker GPU/Docker path is optional and often unavailable; prefer `--mode fast` when marker is installed.
- No Transkribus / cloud OCR in this stack.

## License

MIT (see skill frontmatter). Code authored for Hermes fellows packaging.

## Fraktur glyph templates

See `skill/references/fraktur-templates/INDEX.md`. Optional local specimen images help agents disambiguate long‑s, capitals, and ß — not required for OCR runtime.
